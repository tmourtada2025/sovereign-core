export default function Page() {
  return <div>Welcome to the Sovereign Core.</div>;
}